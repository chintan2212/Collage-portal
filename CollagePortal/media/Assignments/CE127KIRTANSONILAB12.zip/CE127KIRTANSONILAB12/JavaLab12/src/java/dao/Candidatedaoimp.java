
package dao;
import java.util.List;
import model.Candidate;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public class Candidatedaoimp implements Candidatedao {

    @Autowired
    private SessionFactory sessionFactory;
    
    @Override
    public void addCandidate(Candidate can) {
        sessionFactory.getCurrentSession().saveOrUpdate(can);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Candidate> getAllCandidate() {
        return sessionFactory.getCurrentSession().createQuery("from Candidate").list(); /
    }

    @Override
    public void deleteCandidate(Integer id) {
        Candidate candidate=sessionFactory.getCurrentSession().load(Candidate.class, id);
        sessionFactory.getCurrentSession().delete(candidate); 
    }

    @Override
    public Candidate getCandidate(int id) {
        return (Candidate) sessionFactory.getCurrentSession().get(Candidate.class,id); 
    }

    @Override
    public Candidate updateCandidate(Candidate can) {
        sessionFactory.getCurrentSession().update(can);
        return can;
    }
    
}
