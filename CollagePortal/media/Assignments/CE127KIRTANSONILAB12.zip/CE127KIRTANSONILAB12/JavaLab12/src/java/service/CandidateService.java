package service;
import java.util.List;
import model.Candidate;


public interface CandidateService {
    
    public void addCandidate(Candidate can);
    public List<Candidate> getAllCandidate();
    public void deleteCandidate(Integer id);
    public Candidate getCandidate(int id);
    public Candidate updateCandidate(Candidate can);
    
}

