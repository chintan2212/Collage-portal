package dao;
import java.util.List;
import model.Candidate;

public interface Candidatedao {
    public void addCandidate(Candidate can);
    public List<Candidate> getAllCandidate();
    public void deleteCandidate(Integer id);
    public Candidate getCandidate(int id);
    public Candidate updateCandidate(Candidate can);
    
}
