package service;
import dao.Candidatedao;
import java.util.List;
import model.Candidate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class CandidateServiceimp implements CandidateService{
    
    @Autowired
    private Candidatedao candidateDao;

    @Override
    @Transactional
    public void addCandidate(Candidate can) {
        candidateDao.addCandidate(can); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    @Transactional
    public List<Candidate> getAllCandidate() {
        return candidateDao.getAllCandidate(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    @Transactional
    public void deleteCandidate(Integer id) {
        candidateDao.deleteCandidate(id); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Candidate getCandidate(int id) {
        return candidateDao.getCandidate(id); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Candidate updateCandidate(Candidate can) {
        return candidateDao.updateCandidate(can); //To change body of generated methods, choose Tools | Templates.
    }
}

