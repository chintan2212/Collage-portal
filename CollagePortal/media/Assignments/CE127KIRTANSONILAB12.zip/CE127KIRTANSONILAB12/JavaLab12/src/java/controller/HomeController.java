package controller;
import javax.servlet.http.HttpServletRequest;
import model.Candidate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import service.CandidateService;

@Controller
public class HomeController {
    
    @Autowired
    CandidateService candidateService;
    
    @RequestMapping("/")
    public ModelAndView home(ModelAndView model){
        model.addObject("allcandidate", candidateService.getAllCandidate());
        model.setViewName("home");
        return model;
    }
    
    @RequestMapping(value="/form")
    public ModelAndView form(ModelAndView model){
        Candidate candidate=new Candidate();
        model.addObject("candidate", candidate);
        model.setViewName("RegisterForm");
        return model;
    }
    
    @RequestMapping(value="/saveCandidate", method=RequestMethod.POST )
    public ModelAndView save(@ModelAttribute Candidate candidate){
        //System.out.println(candidate.getId());
        if(candidate.getId() == null)
        {
            candidateService.addCandidate(candidate);
        }
        else
        {
            candidateService.updateCandidate(candidate);
        }
        return new ModelAndView("redirect:/");
    }
    
    
    @RequestMapping(value="/editCandidate", method=RequestMethod.GET )
    public ModelAndView edit(HttpServletRequest request)
    {
        int id=Integer.parseInt(request.getParameter("id"));
        Candidate candidate=candidateService.getCandidate(id);
        ModelAndView model=new ModelAndView("RegisterForm");
        model.addObject("candidate", candidate);
        return model;
    }
    
    @RequestMapping(value="/deleteCandidate",method=RequestMethod.GET)
    public ModelAndView delete(HttpServletRequest request)
    {
        int id=Integer.parseInt(request.getParameter("id"));
        candidateService.deleteCandidate(id);
        return new ModelAndView("redirect:/");
    }
}

