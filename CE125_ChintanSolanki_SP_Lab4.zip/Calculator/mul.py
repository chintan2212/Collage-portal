def mul(num1, num2):
    return num1*num2
