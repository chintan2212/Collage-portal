def sub(num1, num2):
    return num1-num2
