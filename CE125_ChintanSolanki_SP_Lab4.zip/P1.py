class Counter:
    def __init__(self):
        self.count=0
    def countUp(self):
        self.count=self.count+1